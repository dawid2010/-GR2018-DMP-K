package piggy.bank.web.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class BudgetDto {

    private Long id;

    private PersonDto personDto;

    private List<IncomeDto> incomeDtos;

    private List<OutcomeDto> outcomeDtos;

    @Override
    public String toString() {
        return "BudgetDto{" +
                "id=" + id +
                ", personDto=" + personDto +
                ", incomeDtos=" + incomeDtos +
                ", outcomeDtos=" + outcomeDtos +
                '}';
    }
}