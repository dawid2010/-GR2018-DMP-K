package piggy.bank.web.dto;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class HouseDto {

    private Long id;

    private String name;

//    private String reflink;

    private PersonDto admin;

    private List<PersonDto> users;

    @Override
    public String toString() {
        return "HouseDto{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", admin=" + admin +
                ", users=" + users +
                '}';
    }
}
