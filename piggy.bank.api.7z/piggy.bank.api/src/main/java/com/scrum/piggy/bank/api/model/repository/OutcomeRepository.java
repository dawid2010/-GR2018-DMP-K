package com.scrum.piggy.bank.api.model.repository;

import com.scrum.piggy.bank.api.model.entity.Outcome;
import org.springframework.data.jpa.repository.JpaRepository;

public interface OutcomeRepository extends JpaRepository<Outcome, Long> {

}
