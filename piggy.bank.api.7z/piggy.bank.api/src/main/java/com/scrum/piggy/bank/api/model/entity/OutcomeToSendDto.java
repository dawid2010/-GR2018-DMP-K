package com.scrum.piggy.bank.api.model.entity;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class OutcomeToSendDto {

    private Double value;

    private String name;

    private Integer account_id;

    private String data;

    private String type;

    public OutcomeToSendDto(Outcome outcome){
        this.value = outcome.getValue();
        this.name = outcome.getName();
        this.account_id = 1;
        this.data = "2019-01-26";
        this.type = Type.ZYWNOSC.toString();
    }
}
