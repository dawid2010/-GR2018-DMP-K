package com.scrum.piggy.bank.api.model.entity;

import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;

@Data
@Entity
public class Outcome {

    public Outcome(){}

    public Outcome(OutcomeToSendDto outcomeToSendDto){
        this.name = outcomeToSendDto.getName();
        this.value = outcomeToSendDto.getValue();
        this.budget = null;
        this.type = Type.ZYWNOSC;
    }

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    private String name;

    private Double value;

    private Type type;

    @ManyToOne
    @JoinColumn(name = "budget_id")
    private Budget budget;
}
