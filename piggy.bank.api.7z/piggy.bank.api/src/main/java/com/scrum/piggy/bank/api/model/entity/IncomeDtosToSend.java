package com.scrum.piggy.bank.api.model.entity;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class IncomeDtosToSend {
    Set<IncomeToSendDto> incomeToSendDtos;

    public IncomeDtosToSend(List<Income> income){
        this.incomeToSendDtos = income.stream().map(IncomeToSendDto::new).collect(Collectors.toSet());
    }
}
