package com.scrum.piggy.bank.api.api;

import com.google.common.collect.ImmutableSet;
import com.scrum.piggy.bank.api.model.entity.*;
import com.scrum.piggy.bank.api.model.repository.IncomeRepository;
import com.scrum.piggy.bank.api.model.repository.OutcomeRepository;
import com.scrum.piggy.bank.api.model.repository.PersonRepository;
import org.springframework.web.bind.annotation.*;

import javax.persistence.EntityNotFoundException;
import javax.persistence.GeneratedValue;
import java.util.Set;
import java.util.stream.Collectors;


@RestController
public class PersonController {

    private final PersonRepository personRepository;

    private final OutcomeRepository outcomeRepository;

    private final IncomeRepository incomeRepository;

    public PersonController(PersonRepository personRepository,
                            OutcomeRepository outcomeRepository,
                            IncomeRepository incomeRepository) {
        this.personRepository = personRepository;
        this.outcomeRepository = outcomeRepository;
        this.incomeRepository = incomeRepository;
    }

    @GetMapping("person/all")
    public Set<Person> findAll(){
        return ImmutableSet.copyOf(personRepository.findAll());
    }

    @GetMapping("/person/{id}")
    public Person findById(@PathVariable("id") Person person){
        return person;
    }

    @GetMapping("/person?budgetId={budget_id}")
    public Person findByBudget(@PathVariable("budget_id") Budget budget){
        return personRepository.findByBudget(budget).orElseThrow(() ->
                new EntityNotFoundException("elo"));
    }

    @GetMapping("/outcome/all")
    public OutcomeDtosToSend findAllOutcomes(){
        return new OutcomeDtosToSend(outcomeRepository.findAll());
    }

    @PostMapping("/outcome/add")
    public OutcomeToSendDto newOutcomeToSendDto(@RequestBody OutcomeToSendDto outcomeToSendDto){
        outcomeRepository.save(new Outcome(outcomeToSendDto));
        return outcomeToSendDto;
    }

    @GetMapping("/income/all")
    public IncomeDtosToSend findAllIncomes(){
        return new IncomeDtosToSend(incomeRepository.findAll());
    }

    @PostMapping("/income/add")
    public IncomeToSendDto newIncomeToSendDto(@RequestBody IncomeToSendDto incomeToSendDto){
        incomeRepository.save(new Income(incomeToSendDto));
        return incomeToSendDto;
    }
}
