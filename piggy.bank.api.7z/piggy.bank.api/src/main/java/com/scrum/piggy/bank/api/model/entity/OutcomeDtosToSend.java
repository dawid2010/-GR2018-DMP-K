package com.scrum.piggy.bank.api.model.entity;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class OutcomeDtosToSend {
    Set<OutcomeToSendDto> outcomeToSendDtos;

    public OutcomeDtosToSend(List<Outcome> outcomes){
        this.outcomeToSendDtos = outcomes.stream().map(OutcomeToSendDto::new).collect(Collectors.toSet());
    }
}
