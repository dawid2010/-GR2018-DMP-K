package com.scrum.piggy.bank.api.model.entity;

import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;

@Data
@Entity
public class Income {

    public Income(){}

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    private String name;

    private Double value;

    @ManyToOne
    @JoinColumn(name = "budget_id")
    private Budget budget;

    private Type type;

    public Income(IncomeToSendDto incomeToSendDto){
        this.name = incomeToSendDto.getName();
        this.value = incomeToSendDto.getValue();
        this.budget = null;
        this.type = Type.STUDIA;
    }
}
