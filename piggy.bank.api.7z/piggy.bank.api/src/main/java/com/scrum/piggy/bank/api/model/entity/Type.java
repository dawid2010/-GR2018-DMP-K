package com.scrum.piggy.bank.api.model.entity;

public enum Type {
    ZYWNOSC,
    STUDIA
}
