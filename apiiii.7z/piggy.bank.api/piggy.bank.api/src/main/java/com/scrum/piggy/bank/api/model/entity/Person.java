package com.scrum.piggy.bank.api.model.entity;

import lombok.*;

import javax.persistence.*;

@Data
@Entity
@RequiredArgsConstructor
@AllArgsConstructor
public class Person {

    public Person(){}

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;
    @NonNull
    private String login;
    @NonNull
    private String password;
    @NonNull
    private String email;
    @NonNull
    private String firstName;
    @NonNull
    private String lastName;

    @OneToOne
    @JoinColumn(name = "budget_owner_id")
    private Budget budget;

    @OneToOne
    @JoinColumn(name = "admin_id")
    private House house;

    @ManyToOne
    @JoinColumn(name = "house_id")
    private House participatedHouse;
}
