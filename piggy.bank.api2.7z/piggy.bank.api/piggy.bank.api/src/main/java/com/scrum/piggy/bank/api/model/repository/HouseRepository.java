package com.scrum.piggy.bank.api.model.repository;

import com.scrum.piggy.bank.api.model.dao.House;
import org.springframework.data.jpa.repository.JpaRepository;

public interface HouseRepository extends JpaRepository<House, Long> {
}
