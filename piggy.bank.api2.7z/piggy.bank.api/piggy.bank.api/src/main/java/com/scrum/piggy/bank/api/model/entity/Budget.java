package com.scrum.piggy.bank.api.model.entity;

import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.util.List;

@Data
@Entity
public class Budget {

    public Budget(){}

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @OneToOne(mappedBy = "budget", cascade = CascadeType.ALL,
            fetch = FetchType.LAZY, optional = false)
    private Person person;

    @OneToMany(mappedBy = "budget", cascade = CascadeType.ALL)
    private List<Income> incomes;

    @OneToMany(mappedBy = "budget", cascade = CascadeType.ALL)
    private List<Outcome> outcomes;
}