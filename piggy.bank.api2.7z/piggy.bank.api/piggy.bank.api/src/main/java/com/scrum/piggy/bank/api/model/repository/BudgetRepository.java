package com.scrum.piggy.bank.api.model.repository;

import com.scrum.piggy.bank.api.model.dao.Budget;
import org.springframework.data.jpa.repository.JpaRepository;

public interface BudgetRepository extends JpaRepository<Budget, Long> {

}
