package com.scrum.piggy.bank.api.model.dto;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.scrum.piggy.bank.api.model.dao.House;
import lombok.*;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Getter
@ToString
public class HouseDto {

    private Long id;

    private String name;

//    private String reflink;

    private PersonDto admin;

    private List<PersonDto> users;

    public HouseDto(House house) {
        this.id = house.getId();
        this.name = house.getName();
        this.admin = new PersonDto(house.getAdmin());
        this.users = house.getUsers().stream().map(PersonDto::new).collect(Collectors.toList());
    }
}
