package com.scrum.piggy.bank.api.model.entity;


import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;

import javax.persistence.*;
import java.util.List;

@Data
@Entity
@RequiredArgsConstructor
public class House {

    public House(){}

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @NonNull
    private String name;

//    private String reflink;

    @OneToOne(mappedBy = "house", cascade = CascadeType.ALL,
            fetch = FetchType.LAZY, optional = false)
    private Person admin;

    @OneToMany(mappedBy = "house", cascade = CascadeType.ALL)
    private List<Person> users;
}
