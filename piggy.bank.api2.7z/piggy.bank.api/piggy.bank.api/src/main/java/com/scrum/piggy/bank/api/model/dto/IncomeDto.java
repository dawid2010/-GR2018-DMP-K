package com.scrum.piggy.bank.api.model.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.scrum.piggy.bank.api.model.dao.Income;
import lombok.*;

@Getter
@ToString
public class IncomeDto {

    private Long id;

    private String name;

    private Double value;

    public IncomeDto(Income income) {
        this.id = income.getId();
        this.name = income.getName();
        this.value = income.getValue();
    }
}
