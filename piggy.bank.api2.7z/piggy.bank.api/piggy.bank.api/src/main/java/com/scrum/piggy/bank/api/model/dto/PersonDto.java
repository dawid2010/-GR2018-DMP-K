package com.scrum.piggy.bank.api.model.dto;

import com.scrum.piggy.bank.api.model.dao.Person;
import lombok.*;

@Getter
@ToString
public class PersonDto {

    private Long id;

    private String login;

    private String password;

    private String email;

    private String firstName;

    private String lastName;

    public PersonDto(Person person) {
        this.id = person.getId();
        this.login = person.getLogin();
        this.password = person.getPassword();
        this.email = person.getEmail();
        this.firstName = person.getFirstName();
        this.lastName = person.getLastName();
    }
}
