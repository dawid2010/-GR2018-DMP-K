package com.scrum.piggy.bank.api.model.dao;

import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;

@Data
@Entity
@NoArgsConstructor
public class Outcome {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    private String name;

    private Double value;

    @ManyToOne
    @JoinColumn(name = "budget_id")
    private Budget budget;
}
