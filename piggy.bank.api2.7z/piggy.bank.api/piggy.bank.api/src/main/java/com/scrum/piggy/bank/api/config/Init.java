package com.scrum.piggy.bank.api.config;

import com.scrum.piggy.bank.api.model.dao.Budget;
import com.scrum.piggy.bank.api.model.dao.Person;
import com.scrum.piggy.bank.api.model.repository.BudgetRepository;
import com.scrum.piggy.bank.api.model.repository.HouseRepository;
import com.scrum.piggy.bank.api.model.repository.PersonRepository;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;

@Component
public class Init {

    private final PersonRepository personRepository;

    private final BudgetRepository budgetRepository;

    private final HouseRepository houseRepository;

    public Init(PersonRepository personRepository,
                BudgetRepository budgetRepository,
                HouseRepository houseRepository) {
        this.personRepository = personRepository;
        this.budgetRepository = budgetRepository;
        this.houseRepository = houseRepository;
    }

    @PostConstruct
    public void init(){
        Person person = personRepository.save(new Person(
                "login",
                "password",
                "email@gmail.com",
                "firstName",
                "lastName"));
        Budget budget = budgetRepository.save(new Budget());

        person.setBudget(budget);
        personRepository.save(person);
    }
}
