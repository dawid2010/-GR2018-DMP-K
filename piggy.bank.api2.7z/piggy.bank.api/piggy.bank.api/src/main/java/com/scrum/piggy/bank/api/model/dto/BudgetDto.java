package com.scrum.piggy.bank.api.model.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.*;

import java.util.List;

@Getter
@ToString
public class BudgetDto {

    private Long id;

    private PersonDto personDto;

    private List<IncomeDto> incomeDtos;

    private List<OutcomeDto> outcomeDtos;
}