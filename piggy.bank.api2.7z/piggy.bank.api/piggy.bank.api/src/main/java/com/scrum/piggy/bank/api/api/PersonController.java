package com.scrum.piggy.bank.api.api;

import com.google.common.collect.ImmutableSet;
import com.scrum.piggy.bank.api.model.entity.Budget;
import com.scrum.piggy.bank.api.model.entity.Person;
import com.scrum.piggy.bank.api.model.repository.PersonRepository;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import javax.persistence.EntityNotFoundException;
import java.util.Set;


@RestController
public class PersonController {

    private final PersonRepository personRepository;

    public PersonController(PersonRepository personRepository) {
        this.personRepository = personRepository;
    }

    @GetMapping("person/all")
    public Set<Person> findAll(){
        return ImmutableSet.copyOf(personRepository.findAll());
    }

    @GetMapping("/person/{id}")
    public Person findById(@PathVariable("id") Person person){
        return person;
    }

    @GetMapping("/person?budgetId={budget_id}")
    public Person findByBudget(@PathVariable("budget_id") Budget budget){
        return personRepository.findByBudget(budget).orElseThrow(() ->
                new EntityNotFoundException("elo"));
    }
}
