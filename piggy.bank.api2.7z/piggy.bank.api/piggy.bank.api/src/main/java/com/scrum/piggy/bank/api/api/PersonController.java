package com.scrum.piggy.bank.api.api;

import com.google.common.collect.ImmutableSet;
import com.scrum.piggy.bank.api.model.dao.Budget;
import com.scrum.piggy.bank.api.model.dao.Person;
import com.scrum.piggy.bank.api.model.dto.PersonDto;
import com.scrum.piggy.bank.api.model.repository.PersonRepository;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.persistence.EntityNotFoundException;
import java.util.Set;
import java.util.stream.Collectors;

@RestController
public class PersonController {

    private final PersonRepository personRepository;

    public PersonController(PersonRepository personRepository) {
        this.personRepository = personRepository;
    }

    @GetMapping("person/all")
    public Set<PersonDto> findAll(){
        return ImmutableSet.copyOf(personRepository.findAll().stream()
                .map(PersonDto::new)
                .collect(Collectors.toSet()));
    }

    @GetMapping("/person/{id}")
    public PersonDto findById(@PathVariable("id") Person person){
        return new PersonDto(person);
    }

    @GetMapping("/person")
    public PersonDto findByBudget(@RequestParam("budgetId") Budget budget){
        Person person = personRepository.findByBudget(budget).orElseThrow(() ->
                new EntityNotFoundException("elo"));
        return new PersonDto(person);
    }
}
