﻿using System;
using System.Collections.Generic;
using System.Data.Entity.Migrations;
using System.Globalization;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using ClassLibrary;

namespace SerwerAPISkarbonka.Controllers
{
    public class GoalsController : ApiController
    {
        public IEnumerable<Goal> Get()
        {
            using (sEntities entities = new sEntities())
            {

                entities.Configuration.ProxyCreationEnabled = false;
                return entities.Goals.ToList();
            }
        }

        public Goal Get(int id)
        {
            using (sEntities entities = new sEntities())
            {
                entities.Configuration.ProxyCreationEnabled = false;
                return entities.Goals.FirstOrDefault(e => e.id == id);
            }
        }

        public IEnumerable<Goal> Get(int id, int a)
        {
            using (sEntities entities = new sEntities())
            {

                entities.Configuration.ProxyCreationEnabled = false;
                List<Goal> wynik = new List<Goal>();
                  
                foreach (Goal g in entities.Goals.ToList())
                {
                    if (g.account_id == id)
                    {
                        wynik.Add(g);
                    }
                }
                return wynik;
            }
        }

       


        public void Post(decimal value, string name, int account_id)
        {
            using (sEntities entities = new sEntities())
            {
                entities.Configuration.ProxyCreationEnabled = false;
                Goal o = new Goal();
                o.value = value;
                o.name = name;
                o.account_id = account_id;
                o.date = DateTime.Now;
                entities.Goals.Add(o);
                entities.SaveChanges();
            }
        }

        public void Post(decimal value, string name, int account_id,  string data_end)
        {
            using (sEntities entities = new sEntities())
            {
                entities.Configuration.ProxyCreationEnabled = false;
                Goal o = new Goal();
                o.value = value;
                o.name = name;
                o.account_id = account_id;

                o.date = DateTime.Now;
                o.date_end = DateTime.ParseExact(data_end, "yyyy-MM-dd", CultureInfo.InvariantCulture);
                entities.Goals.Add(o);
                entities.SaveChanges();
            }
        }

        public void Post(decimal value, string name, int account_id, string data, string data_end)
        {
            using (sEntities entities = new sEntities())
            {
                entities.Configuration.ProxyCreationEnabled = false;
                Goal o = new Goal();
                o.value = value;
                o.name = name;
                o.account_id = account_id;

                o.date = DateTime.ParseExact(data, "yyyy-MM-dd", CultureInfo.InvariantCulture);
                o.date_end = DateTime.ParseExact(data_end, "yyyy-MM-dd", CultureInfo.InvariantCulture);
                entities.Goals.Add(o);
                entities.SaveChanges();
            }
        }

        public void Put(int id, decimal value, string name, int account_id)
        {
            using (sEntities entities = new sEntities())
            {
                entities.Configuration.ProxyCreationEnabled = false;
                Goal o = entities.Goals.FirstOrDefault(e => e.id == id);
                o.value = value;
                o.name = name;
                o.account_id = account_id;
                o.date = DateTime.Now;
                entities.Goals.AddOrUpdate(o);
                entities.SaveChanges();
            }
        }

        public void Put(int id, decimal value, string name, int account_id, string data, string data_end)
        {
            using (sEntities entities = new sEntities())
            {
                entities.Configuration.ProxyCreationEnabled = false;
                Goal o = entities.Goals.FirstOrDefault(e => e.id == id);
                o.value = value;
                o.name = name;
                o.account_id = account_id;

                o.date = DateTime.ParseExact(data, "yyyy-MM-dd", CultureInfo.InvariantCulture);
                o.date_end = DateTime.ParseExact(data_end, "yyyy-MM-dd", CultureInfo.InvariantCulture);
                entities.Goals.AddOrUpdate(o);
                entities.SaveChanges();
            }
        }

        public void Delete(int id)
        {
            using (sEntities entities = new sEntities())
            {
                entities.Configuration.ProxyCreationEnabled = false;
                Goal o = entities.Goals.FirstOrDefault(e => e.id == id);
                entities.Goals.Remove(o);
                entities.SaveChanges();
            }
        }
    }
}
