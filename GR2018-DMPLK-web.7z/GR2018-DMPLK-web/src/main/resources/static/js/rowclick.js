function rowClicked(value) {
    location.href = value;
}