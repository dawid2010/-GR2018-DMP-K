package com.piggy.bank.web.exceptions;


public class NoPersonFoundException extends RuntimeException {
}