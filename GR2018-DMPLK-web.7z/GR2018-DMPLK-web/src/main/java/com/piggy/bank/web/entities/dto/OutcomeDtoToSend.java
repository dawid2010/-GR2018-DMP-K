package com.piggy.bank.web.entities.dto;

import com.piggy.bank.web.entities.budget.Outcome;
import lombok.Data;

import java.util.Random;

@Data
public class OutcomeDtoToSend {

    private Double value;

    private String name;

    private Integer account_id;

    private String data;

    private String type;

    public OutcomeDtoToSend(Outcome outcome) {
        this.value = outcome.getValue();
        this.name = outcome.getName();
        this.account_id = 1;
        this.data = "2019-01-25";
        this.type = "ZYWNOSC";
    }
}
