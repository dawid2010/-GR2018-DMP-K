package com.piggy.bank.web.exceptions;

public class InternalServerException extends RuntimeException {
}
