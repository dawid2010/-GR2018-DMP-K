package com.piggy.bank.web.exceptions;

public class NoAttachmentFoundException extends RuntimeException {
}