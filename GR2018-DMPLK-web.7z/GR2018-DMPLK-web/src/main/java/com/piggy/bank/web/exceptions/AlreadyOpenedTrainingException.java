package com.piggy.bank.web.exceptions;

public class AlreadyOpenedTrainingException extends RuntimeException {
}
