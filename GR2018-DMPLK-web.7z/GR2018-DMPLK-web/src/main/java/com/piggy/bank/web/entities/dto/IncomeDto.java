package com.piggy.bank.web.entities.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.sql.Timestamp;

@Data
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class IncomeDto {

    private Long id;

    private String name;

    private Double value;

    private Timestamp date;

    private Long account_id;

    private Account account;
}
