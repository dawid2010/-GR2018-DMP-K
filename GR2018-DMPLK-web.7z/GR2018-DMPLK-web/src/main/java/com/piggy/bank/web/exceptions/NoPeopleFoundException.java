package com.piggy.bank.web.exceptions;

public class NoPeopleFoundException extends RuntimeException {
}