package com.piggy.bank.web.exceptions;

public class WrongArgumentException extends RuntimeException {
}