package com.piggy.bank.web.entities.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Set;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class OutcomeDtosToSend {
    Set<OutcomeDtoToSend> outcomeToSendDtos;

    public OutcomeDtosToSend(String json){
    }
}
