package com.piggy.bank.web.entities.budget;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.piggy.bank.web.entities.dto.IncomeDto;
import com.piggy.bank.web.entities.dto.OutcomeDto;
import com.piggy.bank.web.entities.dto.OutcomeDtoToSend;
import lombok.*;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.util.Map;
import java.util.Random;

/**
 * Class that represents budget schema for usable trainings
 */
@Entity
@Getter
@Setter
@AllArgsConstructor
@RequiredArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class Outcome{
    @Id
    private Long id;

    @NonNull
    @NotNull
    @Size(min = 3, max = 200, message = "{error.budget.adding.name.Size}")
    private String name;

    private Double value;

    @Enumerated(EnumType.STRING)
    @NonNull
    private Type type;

    public enum Type {
        BRONZE("Sport"),
        SILVER("Transport"),
        GOLD("Chemia");

        Type(String displayName) {
            this.displayName = displayName;
        }

        private String displayName;

        public String getDisplayName() {
            return displayName;
        }
    }

    public Outcome(@Size(min = 3, max = 30, message = "{error.budget.adding.name.Size}") String name,
                   Double value, Type type) {
        this.name = name;
        this.value = value;
        this.type = type;
    }

    @Override
    public String toString() {
        return "Outcome{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", value=" + value +
                ", type=" + type +
                '}';
    }

    public Outcome(OutcomeDtoToSend outcomeDto) {
        this.name = outcomeDto.getName();
        this.value = outcomeDto.getValue();
        this.type = Type.BRONZE;
    }

    public Outcome(Map<String, Object> outcomeJson){
        this.name = (String) outcomeJson.get("name");
        this.value = (Double) outcomeJson.get("value");
        this.type = Outcome.Type.BRONZE;
    }
}
