package com.piggy.bank.web.entities.budget;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.piggy.bank.web.entities.dto.IncomeDto;
import com.piggy.bank.web.entities.dto.IncomeDtoToSend;
import com.piggy.bank.web.entities.dto.OutcomeDtoToSend;
import lombok.*;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.util.Map;
import java.util.Random;

@Entity
@Getter
@Setter
@AllArgsConstructor
@RequiredArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class Income implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NonNull
    @NotNull
    private String name;

    private Double value;

    @Enumerated(EnumType.STRING)
    @NonNull
    private Type type;


    public enum Type {
        BRONZE("Praca"),
        SILVER("Zasiłek"),
        GOLD("Lokata");

        Type(String displayName) {
            this.displayName = displayName;
        }

        private String displayName;

        public String getDisplayName() {
            return displayName;
        }
    }

    @Override
    public String toString() {
        return "Income{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", value=" + value +
                ", type=" + type +
                '}';
    }

    public Income(IncomeDto incomeDto) {
        this.id = incomeDto.getId();
        this.name = incomeDto.getName();
        this.value = incomeDto.getValue();
        this.type = getRandomType();
    }

    private Type getRandomType(){
        Random random = new Random();
        int randomInt = random.nextInt(2);
        switch (randomInt) {
            case 0:
                return Type.BRONZE;
            case 1:
                return Type.SILVER;
            default:
                return Type.GOLD;
        }
    }

    public Income(IncomeDtoToSend incomeDto) {
        this.name = incomeDto.getName();
        this.value = incomeDto.getValue();
        this.type = Income.Type.BRONZE;
    }

    public Income(Map<String, Object> incomeJson){
        this.name = (String) incomeJson.get("name");
        this.value = (Double) incomeJson.get("value");
        this.type = Type.BRONZE;
    }
}
