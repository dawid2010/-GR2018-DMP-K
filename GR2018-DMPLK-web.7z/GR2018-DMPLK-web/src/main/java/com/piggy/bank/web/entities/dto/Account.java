package com.piggy.bank.web.entities.dto;

import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@NoArgsConstructor
public class Account implements Serializable {
    private String elo = "elo";
}
