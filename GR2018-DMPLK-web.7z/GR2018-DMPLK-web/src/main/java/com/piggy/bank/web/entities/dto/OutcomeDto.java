package com.piggy.bank.web.entities.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.piggy.bank.web.entities.budget.Outcome;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.sql.Timestamp;
import java.util.Random;

@Data
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class OutcomeDto {

    private Long id;

    private String name;

    private Double value;

    private Timestamp date;

    private Long account_id;

    private String type;

    private Account account;
}
