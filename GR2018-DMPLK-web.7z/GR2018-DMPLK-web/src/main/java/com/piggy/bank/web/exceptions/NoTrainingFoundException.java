package com.piggy.bank.web.exceptions;



public class NoTrainingFoundException extends RuntimeException {
}