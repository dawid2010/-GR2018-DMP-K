package com.piggy.bank.web.entities.dto;

import com.piggy.bank.web.entities.budget.Income;
import com.piggy.bank.web.entities.budget.Outcome;
import lombok.Data;

@Data
public class IncomeDtoToSend {
    private Double value;

    private String name;

    private Integer account_id;

    private String data;

    private String type;

    public IncomeDtoToSend(Income income) {
        this.value = income.getValue();
        this.name = income.getName();
        this.account_id = 1;
        this.data = "2019-01-25";
        this.type = "STUDIA";
    }
}
