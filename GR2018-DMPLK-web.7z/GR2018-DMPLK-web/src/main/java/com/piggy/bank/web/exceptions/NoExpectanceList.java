package com.piggy.bank.web.exceptions;

public class NoExpectanceList extends RuntimeException {
}
