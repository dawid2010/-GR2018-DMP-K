# GR2018-DMPLK
Grupa wykonująca projekt w ramach przedmiotu z zwinnych metodyk tworzenia oprogramowania
